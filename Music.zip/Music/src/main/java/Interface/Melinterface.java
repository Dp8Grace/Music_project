package Interface;

import org.example.Finale;
import org.jfugue.player.Player;

import javax.swing.*;
import java.awt.event.*;

public class Melinterface extends JDialog {
    static Player player=new Player();
    private JPanel contentPane;
    private JButton buttonPLAY;
    private JComboBox Strumento;
    private JComboBox Stile;
    private JPanel JPanelRisultato;
    private JTextArea Risultato;
    public JCheckBox strumentaleCheckBox;

    public static String sceltaS; //STRUMENTO
    public static String sceltaP; //PORTAMENTO

    public static boolean check=false;

    public static int scelta1;//->
    public static int scelta2;//variabili globali0 che serviranno per dire in che posizione dell'array deve prendere strumento e stile i metodo play

    private String[] selezioniS = {"Piano", "Violin", "Warm", "Flute", "Guitar", "Acoustic_Bass", "Voice"};//STRMNT
    private String[] selezioniP = {"Allegro","Moderato","Adagio"};//PRTMNT

    private final static String newline = "\n";



    public Melinterface() {
        setContentPane(contentPane);

        setModal(true);
        getRootPane().setDefaultButton(buttonPLAY);

        //Run per il Risultato;
        class playListner implements ActionListener { //STRUMENTO PORTAMENTO

            @Override
            public void actionPerformed(ActionEvent e) { //stampa la scelta (scelta)
                sceltaS = Strumento.getSelectedItem().toString();
                //System.out.println("scelta strumento" + sceltaS);
                sceltaP = Stile.getSelectedItem().toString();
                //System.out.println("scelta stile" + sceltaP);
                System.out.print("\n");
                strumentaleCheckBox();
                StrumentoScelta();
                StileScelta();
                Risultato();
            }
        }
        ActionListener PLAY = new playListner();
        buttonPLAY.addActionListener(PLAY);//aggiunge il listener al pulsante (STRUMENTO)
    }

    public void StrumentoScelta(){
        System.out.println(Strumento.getSelectedItem());
        scelta1 = Strumento.getSelectedIndex();
        //System.out.println("intero: "+scelta1);
    }

    public void strumentaleCheckBox(){
        if(strumentaleCheckBox.isSelected()){
            //System.out.println("Hai selezionato la strumentale");
            check=true;
        }
    }

    public void StileScelta(){
        System.out.println(Stile.getSelectedItem());
        scelta2 = Stile.getSelectedIndex();
        //System.out.println("intero: "+scelta2);
    }

        public void Risultato () {
            Risultato.setEditable(false);
            Risultato.setText("Risultato:");
            String[] a = new String[]{" "+Stile.getSelectedItem(),""+Strumento.getSelectedItem()};
            Finale.main(a);//invoco il main Finale
            Risultato.setLineWrap(true);
            Risultato.append(newline+Finale.musicFinale);
    }

        public static void main (String[]args){
            Melinterface dialog = new Melinterface();
            dialog.pack();
            dialog.setSize(1000, 400);
            dialog.setLocationRelativeTo(null);
            dialog.setResizable(false);//centro schermo
            dialog.setVisible(true);
            System.exit(0);//chiude i processi alla fine del programma
        }

}

