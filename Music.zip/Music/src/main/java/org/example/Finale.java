package org.example;
import Interface.Melinterface;
import org.jfugue.player.Player;
import org.jfugue.pattern.Pattern;

import javax.swing.*;
import java.util.*;

import static Interface.Melinterface.*;

public class Finale { //metodi
    static Player player = new Player();
    static Pattern pattern = new Pattern();
    static Random random = new Random();


    //rispettivamente di seguito array di stringhe da aggiungere iniziali e finali
    static String[] initial = new String[]{"Ch Ah+(Ch Eh Gh)", "C#w Ri C4+E4+G4W (D5+G5)i", "D+F+A D+F#+A D+Aw", "A# B+D +A#",
            "Cq+Eq+Gq Cq+Eq+Gq Gh", "Dw+Fw+Aw Dw+Fw Dw+Fw+Aw Dw+Aw", "C4w+(C5+E5)w E4w D4w+(F4+A4)w E4w", "C4w E4w D4w E4w+G4w C4"};

    static String[] finale = new String[]{"Dw+Fw+Aw Dw+Fw Dw+Fw+Aw Dw+Aw", "C4w+C5w+C6W C6+C4",
            "C4w+C5w+C6W C6h+C4h C6+C5 C5+C4 C4w", "C4w C5w+A5w A5 A5 C4w C4w", "C4w E#4w D4w E4w+G4w C4+G3", "D4+F#4+A4 F#4+A4 D4+A4"};

    static String[] duration = new String[]{"w", "h", "q"};//durate dalla semibreve alla semiminima

    //array di stringhe contenente le ottave utilizzate da questo programma(dalla terza alla quinta ottava)
    static String[] notes = {"C3", "D3", "E3", "F3", "G3", "A3", "B3", "R",
            "C4", "D4", "E4", "F4", "G4", "A4", "B4", "R",
            "C5", "D5", "E5", "F5", "G5", "A5", "B5", "R", "R"};

    public static String[] instrument = new String[]{"Piano", "Violin", "Warm", "Flute", "Guitar", "Acoustic_Bass", "Voice"};
    public static String[] stile ={"Allegro","Moderato","Adagio"};

    public static String music = " ";
     static  String middle = " ";
     public static String musicFinale;
     public static Pattern V1=new Pattern(" ");
     public static Pattern V2=new Pattern(" ");

     private static String strumentoFinale,stileFinale;

    public Finale() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
            int first = random.nextInt(initial.length);
            music += initial[first]; //parte iniziale del componimento
            strumentoFinale = args[1];
            stileFinale = args[0];
            V1.add(initial[first]);
            for (int i = 0; i < 18; i++) { //LUNHEZZA VARIABILE A SECONDA DELLA DURATA CHE VOGLIAMO ASSUMERE
                int nota = random.nextInt(notes.length);
                middle = middle + notes[nota];
                int durata1 = random.nextInt(duration.length);
                middle += duration[durata1];
                V1.add(duration[durata1]);
            //Controllo delle note più possibile accordo o pausa
            //Do
            if (notes[nota].equals("C3")|| notes[nota].equals("C4") || notes[nota].equals("C5")) {
                String[] chordC = {"+(A4)", "+(E4)", "+(R)", "+(E4+G4)", "+(Eb4+A4)"};
                int chorDO = random.nextInt(chordC.length);
                middle += chordC[chorDO];
                middle += duration[durata1];
            } //Re
            if (notes[nota].equals("D3") || notes[nota].equals("D4") || notes[nota].equals("D5")) {
                String[] chordD = {"+(A4)", "+(R)", "+(F4)", "+(F4+A4)", "+(A4+F5)"};
                int chorRE = random.nextInt(chordD.length);
                middle += chordD[chorRE];
                middle += duration[durata1];
            } //Mi
            if (notes[nota].equals("E3") || notes[nota].equals("E4") || notes[nota].equals("E5")) {
                String[] chordE = {"+(G4)", "+(E4)", "+(E4+G4)", "+(C4)", "+(G4+C4)"};
                int chorMI = random.nextInt(chordE.length);
                middle += chordE[chorMI];
                middle += (String) duration[durata1];
            } //Fa
            if (notes[nota].equals("F3") || notes[nota].equals("F4") || notes[nota].equals("F5")) {
                String[] chordF = {"+(A4)", "+(R)", "+(B4)", "+(A4+C4)", "+(A4+C5)"};
                int chorFA = random.nextInt(chordF.length);
                middle += chordF[chorFA];
                middle += duration[durata1];
            } //Sol
            if (notes[nota].equals("G3") || notes[nota].equals("G4") || notes[nota].equals("G5")) {
                String[] chordG = {"+(C4)", "+(E4)", "+(R)", "+(B4+D4)", "+(D4+D4)"};
                int chorSOL = random.nextInt(chordG.length);
                middle += chordG[chorSOL];
                middle += duration[durata1];
            } //La
            if (notes[nota].equals("A3") || notes[nota].equals("A4") || notes[nota].equals("A5")) {
                String[] chordA = {"+(E4)", "+(C4)", "+(C4+E4)", "+(C4+E4)"};
                int chorLA = random.nextInt(chordA.length);
                middle += chordA[chorLA];
                middle += duration[durata1];
            } //Si
            if (notes[nota].equals("B3") || notes[nota].equals("B4") || notes[nota].equals("B5")) {
                String[] chordB = {"+(D4)", "+(F4)", "+(E4+B4)", "+(D4+G4)"};
                int chorSI = random.nextInt(chordB.length);
                middle += chordB[chorSI];
                middle += duration[durata1];
            }
            middle += " ";
            }//for
            music += middle;
            int last = random.nextInt(finale.length);
            music += finale[last];
            musicFinale = music;
            System.out.println(music);
            // System.out.println(scelta1+"<-strm1,stl2->"+scelta2);
            //System.out.println(args[1]+"(args)strm,stl(args)"+args[0]);
            //System.out.println(strumentoFinale+"StrumFinale,StileFinale"+stileFinale);
            Pattern p1=new Pattern(strumentoFinale);
            V2.add(music);
            Pattern V3=new Pattern(" ");
            V3.add(V1);
              if(check==true){
              player.play(p1.setInstrument("Piano"),V1.setInstrument("Violin"),V2.setInstrument("Guitar").setInstrument("Flute"));
            }else{
                player.play(p1.add(music).setInstrument(instrument[scelta1]).setTempo(stile[scelta2]));
                player.play(p1);
            }
    }//fine main
}